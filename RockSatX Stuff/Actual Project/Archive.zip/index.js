// SERVER SETUP
const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server);


let value = 100;


function randomBoolean() {
    return ((Math.random() >= 0.5)? true : false);
}

function randomFromArray(array) {
    return array[(Math.floor((Math.random()*array.length)))];
}

function randomNum(num){
    return (Math.round(Math.random()*num));
}

function JSONNode(name) {
    return {
        "name": name,
        "sub_head": {
            "0": randomFromArray(['2.4GHz', '915MHz']),
            "1": randomFromArray(['EC1', 'EC2', 'Payload', 'Base', 'Relay']),
            "2": randomFromArray(['TBD'])
        },

        "quat" : {
            "x": 123,
            "y": 123,
            "z": 123,
            "w": 123
        },
        "alarm": {
            "trx": {"title": 'TRX', "color": randomFromArray(['green', 'red'])},
            "cocom": {"title": 'COCOM', "color": randomFromArray(['green', 'red'])},
            "gps": {"title": 'GPS', "color": randomFromArray(['green', 'red'])},
            "temp": {"title": 'TEMP', "color": randomFromArray(['green', 'red'])}
        },
        "con_stat": {
            "node1": {"title": 'N1', "color": randomFromArray(['green', 'red'])},
            "node2": {"title": 'N2', "color": randomFromArray(['green', 'red'])},
            "node3": {"title": 'N3', "color": randomFromArray(['green', 'red'])},
            "node4": {"title": 'N4', "color": randomFromArray(['green', 'red'])},
            "node5": {"title": 'N5', "color": randomFromArray(['green', 'red'])}
        },
        "master_conn": {
            "2.4GHz": {
                "SNR": {
                    "num": randomNum(100),
                    "color": randomFromArray(['green', 'red', 'blue', 'pink'])
                },
                "RSSI": {
                    "num": randomNum(100),
                    "color": randomFromArray(['green', 'red', 'blue', 'pink'])
                }
            },
            "915MHz": {
                "SNR": {
                    "num": randomNum(100),
                    "color": randomFromArray(['green', 'red', 'blue', 'pink'])
                },
                "RSSI": {
                    "num": randomNum(100),
                    "color": randomFromArray(['green', 'red', 'blue', 'pink'])
                }
            }
        }
    };

}


// SOCKET IO

function sendData() {
	let main = setInterval(() => {
		let nodesObject = {
            "1": JSONNode('EC1'),
            "2": JSONNode('EC2'),
            "3": JSONNode('Relay'),
            "4": JSONNode('Base Station'),
            "5": JSONNode('Payload'),
            "temp1": randomNum(100),
            "alt1": randomNum(10000),
            "speed1": randomNum(150),
            "TBD1": randomNum(500),

            "temp2": randomNum(100),
            "alt2": randomNum(10000),
            "speed2": randomNum(150),
            "TBD2": randomNum(500),

            "temp3": randomNum(100),
            "alt3": randomNum(10000),
            "speed3": randomNum(150),
            "TBD3": randomNum(500),

            "comms": {
                "relay": {
                    "toEC1": {
                        "2.4GHz": randomBoolean(),
                        "915MHz": randomBoolean()
                    },
                    "toEC2": {
                        "2.4GHz": randomBoolean(),
                        "915MHz": randomBoolean()
                    },
                    "toBase": {
                        "2.4GHz": randomBoolean(),
                        "915MHz": randomBoolean()
                    },
                    "toPD": {
                        "2.4GHz": randomBoolean(),
                        "915MHz": randomBoolean()
                    } 
                },
                "PD": {
                    "toEC1": {
                        "2.4GHz": randomBoolean(),
                        "915MHz": randomBoolean()
                    },
                    "toEC2": {
                        "2.4GHz": randomBoolean(),
                        "915MHz": randomBoolean()
                    },
                },
                "base":{
                    "toEC1": {
                        "2.4GHz": randomBoolean(),
                        "915MHz": randomBoolean()
                    },
                    "toEC2": {
                        "2.4GHz": randomBoolean(),
                        "915MHz": randomBoolean()
                    }
                }
            },
        }
		io.emit('data', JSON.stringify(nodesObject));
	}, 1000);
}
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.use(express.static('public'));


let connections = false;
io.on('connection', (socket) => {
	console.log('user connected');
    connections = true
    if (connections){sendData();}
});

server.listen(3000, () => {
    console.log('listening on *:3000');
}); 